#ifndef BTREE
#define BTREE
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <stdbool.h>

//bibliotecas adicionais
#include "recordsHandler.h" //lida em pegar e salvar dados em um arquivo
#include "Node.h"

#define PAGESIZE 4096
#define TREE_HEADER PAGESIZE
#define MAXKEYS 204
#define AUX_FIELDS_SIZE_ON_PAGE (2+1) 
/*number o f key s and ” i s l e a f ”b o ol*/
#define FREE_SPACE_ON_PAGE (PAGESIZE − ( (MAXKEYS∗4 )+(MAXKEYS∗8 ) +((MAXKEYS+1) ∗8 ) +3) )
#define NodeEspace 31;//( (MAXKEYS∗4 )+(MAXKEYS∗8 ) +((MAXKEYS+1) ∗8 ) +3) as maxkey=1




//vai pro arquivo


//vai pra btree

//como é a estrutura da pagina
//temos 4096 records contendo o numero usp, e o rrn
//temos 4096+1 filhos contendo o rrn da posicao da proxima pagina
//um numero de 0 a 4096 que diz quantas records existem na pagina
// um booleano que diz se é folha

typedef struct promotedkey{
    int key;
    long recordRRN;
    long childs[2];
} promotedkey;


btPage *getOrCreateRoot(FILE *) ;
btPage *getRoot(FILE *,long) ;

//logica, primeiro file contem a btree
//segundo file contem os dados armazenados

void bTreeInsert(data *, FILE *,FILE *) ;
 
long bTreeSearch(int , FILE *) ;

void bTreeUpdate(data *, FILE *,FILE *);
#endif