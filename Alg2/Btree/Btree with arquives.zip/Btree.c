
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <stdbool.h>

//bibliotecas adicionais

#include "Btree.h"


    

btPage *getRoot(FILE *input,long rrn){
    
    btPage *auxiliar=page_init(false);//retorno uma pagina vazia e pronta para ser modificada
    auxiliar=getPageFromFile(auxiliar,input,rrn);
    return auxiliar;
    
}


btPage *CreateRoot(FILE *input){
    
    long rrnFinalHeader=createHeader(input);
    
    btPage *auxiliar=page_init(true);

    return auxiliar;
}
btPage *getOrCreateRoot(FILE *input){
    /*como funciona esse codigo, tudo comeca verificando se existe um header, se nao existe, arquivo esta vazio
    entao se cria a raiz e a retorna*/
   //tudo comeca verificando o tamanho do arquivo
   if(fseek(input,0,SEEK_END)==0){
       //nao tem nada dentro entao vamos para criar
        btPage *raiz=CreateRoot(input);
        return raiz;
   }
   else{
       //ja sei que existe um header
       //ler o header, encontrar o rrn da raiz e ler ela
        header *cabecalho=readHeader(input);
        //tenho agora o rrn da raiz procuro ele no arquivo e retorno o no raiz
        
        btPage *raiz=getRoot(input,cabecalho->recordRRN);
        return raiz;
    }


}


//-----------------------------INSERT------------------------------


promotedkey *makePromotedKey(record *dados,long rightRRN){
    promotedkey *aux=(promotedkey*)malloc(sizeof(promotedkey));
    aux->key=dados->key;
    aux->recordRRN=dados->recordRRN;  
    aux->childs[1]=rightRRN;
    return aux;
}

promotedkey *splitChild(btPage* LeftPage,btPage *RightPage,FILE *input,FILE *output) {
   //leftpage tem as informacoes
   //rightpage tem q ser preenchida
	
	
	int j;
	for(j = 0; j < (MAXKEYS/2)-1; j++) {
		RightPage->records[j] = LeftPage->records[j+MAXKEYS/2];//ponho os elementos a partir da
        LeftPage->records[j+MAXKEYS/2].key=-1;//apagando os elementos
        LeftPage->records[j+MAXKEYS/2].key=-1;//apagando os elementos
	}
	
    j=0;
    int numeroDeFilhos=0;
    if(!LeftPage->isLeaf) {//se a pagina nao é filha
		while(LeftPage->childs[j]!=-1){
			numeroDeFilhos++;//verificar quantos filhos existem
            j++;
        }		
	}

    j=0;
	//se a pagina nao é filha
	while(j<numeroDeFilhos/2){
		RightPage->childs[j] = LeftPage->childs[j+numeroDeFilhos/2];
        LeftPage->childs[j+numeroDeFilhos/2]=-1;//vou apagando os elementos
        j++;
	}
	
	
	RightPage->numberOfKeys=MAXKEYS/2;//o numero de elementos fica /2 da lotacao max
	LeftPage->numberOfKeys=MAXKEYS/2;

    record *keyOfPromoted = &LeftPage->records[(MAXKEYS/2)-1];//pego o ultimo elemento da esquerda
    LeftPage->numberOfKeys--;
    LeftPage->records[(MAXKEYS/2)-1].key=-1;//apagando os elementos
    LeftPage->records[(MAXKEYS/2)-1].key=-1;//apagando os elementos
    
    long rightRRN = writePageInFileLastPosition(RightPage,output);
    promotedkey *aux=makePromotedKey(keyOfPromoted,rightRRN);
   
    return aux;

}

promotedkey *insert_non_full(btPage* tree, record *dados,FILE *input, long rrnOfPage,FILE *output) {
	
	int i = (tree->numberOfKeys)-1;
    promotedkey *filhoNovo;
	
	if(tree->isLeaf) {//se é folha fazer a insercao
		while(i >=0 && tree->records[i].key > dados->key) {
			tree->records[i+1] = tree->records[i];
			i--;
		}
        if(tree->numberOfKeys==MAXKEYS-2) {//se com essa chaga na lotacao max 
            //insiro os dados
            tree->records[i+1] = *dados;
		    tree->numberOfKeys++;
            
            //entra no caso de overflow
            //fazer uma nova pagina
            btPage *paginaAuxiliar = page_init(tree->isLeaf);
			filhoNovo= splitChild(tree, paginaAuxiliar,input,output);	
            //escrever a pagina da direita no arquivo	
            writePageInFile(tree,output,rrnOfPage);
            filhoNovo->childs[0]=rrnOfPage;	
            return filhoNovo;
        }
        else{

		    tree->records[i+1] = *dados;
		    tree->numberOfKeys++;
            writePageInFile(tree,output,rrnOfPage);
            return NULL;
        }

	}
	
	else {
		while( i>= 0 && tree->records[i].key > dados->key) {
            
			i--;//para achar o ponto em q dados entra
		}
        long rrnOfThisPage=tree->childs[i];
		tree=getPageFromFile(tree,input,tree->childs[i]);
		filhoNovo=insert_non_full(tree, dados,input, rrnOfThisPage,output);
	}


    if(filhoNovo!=NULL){//significa que preciso tratar ele o colocando na pagina anterior;
        i=tree->numberOfKeys-1;
        while(i >=0 && tree->records[i].key > dados->key) {//aqui eu abro a brecha
			tree->records[i+1] = tree->records[i];
            tree->childs[i+1]= tree->childs[i];//vou passando os rrn tbm
			i--;
		}//encontro a posicao

        //verifico se vai dar overflow
         if(tree->numberOfKeys==MAXKEYS-2) {//se com essa chaga na lotacao max 
            //insiro os dados
            tree->records[i+1].key = filhoNovo->key;
            tree->records[i+1].recordRRN = filhoNovo->recordRRN;
            tree->childs[i+1]=filhoNovo->childs[1];
		    tree->numberOfKeys++;
            //no inserido
            
            //entra no caso de overflow
            //fazer uma nova pagina
            btPage *paginaAuxiliar = page_init(tree->isLeaf);
			filhoNovo= splitChild(tree, paginaAuxiliar,input,output);	
            //escrever a pagina da direita no arquivo	
            writePageInFile(tree,output,rrnOfPage);
            filhoNovo->childs[0]=rrnOfPage;	
            return filhoNovo;
        }
        //se nao der
        else{
            tree->records[i+1].key = filhoNovo->key;
            tree->records[i+1].recordRRN = filhoNovo->recordRRN;
            tree->childs[i+1]=filhoNovo->childs[1];
		    tree->numberOfKeys++;
            //inserir os rrn

            writePageInFile(tree,output,rrnOfPage);
            return NULL;

        }

    }
	
}



void bTreeInsert( data *informacoes, FILE *input,FILE *output){

    //primeiro tem que ser feita a verificacao
    btPage *raiz=getOrCreateRoot(input);
    if(bTreeSearch(informacoes->uspNumber,input)==-1){
        //significa que ja existe uma insercao com esse nUSP
        
        return;
    }
    header *rootHeader=readHeader(input);
    

    //caso contrario
    //escrever no arquivo
    long recordrrn = storeRecordOnFile(informacoes,output);
    promotedkey *filhonovo;
    record *conjuntoDeDados=(record *)malloc(sizeof(record));
    conjuntoDeDados->key=informacoes->uspNumber;
    conjuntoDeDados->recordRRN=recordrrn;

    //tudo comeca procurando uma folha
    if(raiz->isLeaf==true){
        //é uma pagina folha
        if(raiz->numberOfKeys+1<MAXKEYS){
            //ainda cabe aqui dentro
            promotedkey *filhonovo=insert_non_full(raiz,conjuntoDeDados,input,rootHeader->recordRRN,output);
            //reescrever o header
            rootHeader->freeSpace=rootHeader->freeSpace-31;
            setHeader(input,rootHeader);
            
        }
        else{

            filhonovo=insert_non_full(raiz,conjuntoDeDados,input,rootHeader->recordRRN,output);//insiro, aqui ele faz a quebra
            //retorna o filho novo
            btPage *NovaRaiz=page_init(false);//inicio uma pagina para a nova raiz
            
            NovaRaiz->records[0].key=filhonovo->key;
            NovaRaiz->records[0].recordRRN=filhonovo->recordRRN;
            NovaRaiz->numberOfKeys++;
            NovaRaiz->childs[0]=filhonovo->childs[0];
            NovaRaiz->childs[1]=filhonovo->childs[1];

            long raizRrnNovo =writePageInFileLastPosition(NovaRaiz,output);
            rootHeader->recordRRN=raizRrnNovo;
            rootHeader->freeSpace=(PAGESIZE-((1)+(1)+((1+1)*8)+3));//atualizar o free space
            setHeader(input,rootHeader);
        }
    }
    else{
        //aqui vamos ver para qual filho mandar
        //apos encontrar a gente faz recursivamente
        filhonovo=insert_non_full(raiz,conjuntoDeDados,input,rootHeader->recordRRN,output);
        if(filhonovo!=NULL){
             //retorna o filho novo
            btPage *NovaRaiz=page_init(false);//inicio uma pagina para a nova raiz
            NovaRaiz->records[0].key=filhonovo->key;
            NovaRaiz->records[0].recordRRN=filhonovo->recordRRN;
            NovaRaiz->numberOfKeys++;
            NovaRaiz->childs[0]=filhonovo->childs[0];
            NovaRaiz->childs[1]=filhonovo->childs[1];
            long raizRrnNovo =writePageInFileLastPosition(NovaRaiz,output);
            rootHeader->recordRRN=raizRrnNovo;
            rootHeader->freeSpace=(PAGESIZE-((1)+(1)+((1+1)*8)+3));//atualizar o free space
            setHeader(input,rootHeader);
        }
    }

}



 //--------------------------------SEARCH---------------------------------

//verificar se a chave esta na pagina atual
long searchNode(btPage *raiz, int key,FILE *input){
    short contador=0;
    //tratar para caso de filhos
    
    if(raiz->isLeaf){
        while(contador<raiz->numberOfKeys){
        
            if(raiz->records[contador].key==key){
                return raiz->records[contador].recordRRN;//encontrou a chave no no atual, retorna o rrn do arquivo original
            }
            contador++;
        }
        return -1;//nao foi encontrado
    }
    else{
         while(contador<raiz->numberOfKeys){
        
            if(raiz->records[contador].key>=key){
                if(raiz->records[contador].key==key)
                    return raiz->records[contador].recordRRN;//encontrou a chave no no atual, retorna o rrn do arquivo original
                else{
                    break;
                }
            }
            contador++;
        }
        raiz=getPageFromFile(raiz,input,raiz->childs[contador]);
        long resposta=searchNode( raiz,  key, input);
        return resposta;
    }
}

 //TODO implementar
long bTreeSearch(int key, FILE *input){
    
    btPage *raiz=getOrCreateRoot(input);
    //ja tenho a raiz, pois peguei durante o if
    //primeira coisa, verificar se o no esta na raiz
    
    long indicador=searchNode(raiz,key,input);//encontra o rrn do arquivo principal
    if(indicador==-1)printf("Registro nao encontrado\n");
    return indicador;
}

//------------------------UPDATE---------------------
void bTreeUpdate(data *dados, FILE *input,FILE *output){
    //ja tenho a raiz, pois peguei durante o if
    //primeira coisa, verificar se o no esta na raiz
    header *rootHeader=readHeader(input);
    btPage *raiz=getPageFromFile(raiz,input,rootHeader->recordRRN);

    long indicador=bTreeSearch(dados->uspNumber,input);//encontra o rrn do arquivo principal
    if(indicador!=-1)  updateRecordOnFile(dados,output,indicador);
   
    
}