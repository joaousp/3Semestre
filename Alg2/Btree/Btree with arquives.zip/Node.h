#include <stdio.h>
#include <stdbool.h>
#include "Btree.h"
#include "recordsHandler.h"

#ifndef NODE_H
#define NODE_H

//mudei a data para adequar ao tipo pedido
typedef struct data {
	int uspNumber;
	char firstName[50], lastName[50], course[50];
	float grade;
}data;

typedef struct header{
    long recordRRN;
    short freeSpace;
}header;

typedef struct records{
	int key;
	long recordRRN;
}record;
typedef struct page{
    record *records;//ate 204
    long *childs;//ste 204+1
    short numberOfKeys;
    bool isLeaf;
}btPage;


#endif

btPage* page_init(bool isLeaf);