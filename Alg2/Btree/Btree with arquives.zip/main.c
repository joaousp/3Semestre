#include "Btree.h"
#include "recordsHandler.h"
#include <stdio.h>
#include <stdbool.h>



int main() {
  //structuredData *data = openData();
  FILE *input=fopen("Btree.dat","w+b");
  FILE *output=fopen("DataBase.dat","w+b");;

	char operation[11];
	// The loop will always get the operation first
	while(scanf("%s", operation)) {
		data* reference = malloc(RECORDSIZE);
		
		if(!strcmp(operation, "exit")) {
			free(reference);
			break;
		}else if(!strcmp(operation, "insert")) {
			// Reads the CSV input and attaches to the reference record
			scanf("%d,%50[^,],%50[^,],%50[^,],%f", &reference->uspNumber, reference->firstName, reference->lastName, reference->course, &reference->grade);

			bTreeInsert(reference,input,output);
		}else if(!strcmp(operation, "update")) {
			// Reads only the uspNumber to search
			scanf("%d,%50[^,],%50[^,],%50[^,],%f", &reference->uspNumber, reference->firstName, reference->lastName, reference->course, &reference->grade);
			bTreeUpdate(reference,input,output);

				
		}else if(!strcmp(operation, "search")) {
			// Reads only the uspNumber to search
			scanf("%d", &reference->uspNumber);
			long rrn = bTreeSearch(reference->uspNumber,input);

			if(rrn != -1) {
				data* text=getRecordFromFile(output,rrn);
				printRecordInfo(text);
				free(text);
			}else{
				printf("Registro nao encontrado\n");
			}
		}
		else
			printf("Operação inválida!\n");

		free(reference);
	}

	fclose(input);
  	fclose(output);
  return 0;
}