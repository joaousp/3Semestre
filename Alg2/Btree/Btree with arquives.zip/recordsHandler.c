#include "recordsHandler.h"

// Stores the record on data file
long storeRecordOnFile(data *reference, FILE *outputFile) {	
	fwrite(&reference->uspNumber, sizeof(int), 1, outputFile);
	fwrite(&reference->firstName, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->lastName, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->course, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->grade, sizeof(float), 1, outputFile);
	return fseek(outputFile,0,SEEK_END);
}

//updateData
void updateRecordOnFile(data *reference, FILE *outputFile,long rrn) {	
    fseek(outputFile,rrn,SEEK_SET);
	fwrite(&reference->uspNumber, sizeof(int), 1, outputFile);
	fwrite(&reference->firstName, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->lastName, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->course, sizeof(char[50]), 1, outputFile);
	fwrite(&reference->grade, sizeof(float), 1, outputFile);
	
}

// Gets record's info based on a file
data *getRecordFromFile(FILE *output,long rrn) {
    fseek(output,rrn,SEEK_SET);
	data *reference = malloc(sizeof(data));

	// Reads all record's fields
	fread(&reference->uspNumber, sizeof(int), 1, output);
	fread(&reference->firstName, sizeof(char[50]), 1, output);
	fread(&reference->lastName, sizeof(char[50]), 1, output);
	fread(&reference->course, sizeof(char[50]), 1, output);
	fread(&reference->grade, sizeof(float), 1, output);

	return reference;
}

// Prints all record info properly
void printRecordInfo(data *input) {
	printf("-------------------------------\n");
	printf("USP number: %d\n", input->uspNumber);
	printf("Name: %s\n", input->firstName);
	printf("Surname: %s\n", input->lastName);
	printf("Course: %s\n", input->course);
	printf("Test grade: %.2f\n", input->grade);
	printf("-------------------------------\n");
}
//---------------FUNCOES NOVAS DA BTREE------------------

header *readHeader(FILE *input){
    //aqui tudo comeca colocando o arquivo no comeco
    fseek(input, 0,SEEK_SET);
    header *auxiliar=(header*)malloc(sizeof(header));
    //agora leio as informacoes do header
    fread(&auxiliar->recordRRN,sizeof(long),1,input);
    fread(&auxiliar->freeSpace,sizeof(short),1,input);
    return auxiliar;
}
void setHeader(FILE *input, header *newHeader){
	fseek(input,0,SEEK_SET);
    fwrite(&newHeader->recordRRN,1,sizeof(long),input);
    fwrite(&newHeader->freeSpace,1,sizeof(short),input);
}

btPage *getPageFromFile(btPage *auxiliar,FILE* input,long rrn){
    fseek(input,rrn,SEEK_SET);
    //nessa posicao, vai acontecer o seguinte, eu vou ler:
    //se é folha
    //o numero de chaves
    //uma sequencia de records ate 204
    //depois uma sequencia de rrn ate 205
    fread(&auxiliar->isLeaf,sizeof(bool),1,input);
    fread(&auxiliar->numberOfKeys,sizeof(short),1,input);
    //agora ler as chaves
    //lembnrando que chaves vazias sao =-1
    int contador=0;
    while(contador<204){
        //TODO colocar if para erro de leitura
        fread(&auxiliar->records[contador].key,sizeof(int),1,input);
        fread(&auxiliar->records[contador].recordRRN,sizeof(long),1,input);
        contador++;
    }
    //apos essa leitura
    //fora se nao tem rrn=-1
    contador=0;
    while(contador<204){
        fread(&auxiliar->childs[contador],sizeof(long),1,input);
        contador++;
    }
    return auxiliar;
}

//todo alterar header calloc de 4096b
//menset(0)
long createHeader(FILE *input){
    //so por garantia reescrever o header
    fseek(input,0,SEEK_SET);
    header cabecalho;
    cabecalho.recordRRN=sizeof(header);
    cabecalho.freeSpace=PAGESIZE;//a primeira pagina é do header
    fwrite(&cabecalho.recordRRN,1,sizeof(cabecalho.recordRRN),input);
    fwrite(&cabecalho.freeSpace,1,sizeof(cabecalho.freeSpace),input);
    //escrito ate agr 8bytes de 4096, falta 4088
    int ocupaEspaco=-1;
    fwrite(&ocupaEspaco,sizeof(int),1022,input);
    //sao colocados 1022 int de 4b, totalizandp 4088+8 de cima
    // fecha a pagina do header
    return fseek(input,0,SEEK_END);//retorna o ponto final do arquivo
}

void writePageInFile(btPage *pagina,FILE *input,long rrn){
    //aqui, é escrita a pagina no arquivo, na posicao ja definida
    fseek(input,rrn,SEEK_SET);
    fwrite(&pagina->isLeaf,sizeof(bool),1,input);
    fwrite(&pagina->numberOfKeys,sizeof(short),1,input);
    for(int i=0;i<204;i++){
        fwrite(&pagina->records[i].key,sizeof(int),1,input);
        fwrite(&pagina->records[i].recordRRN,sizeof(long),1,input);
    }
    for(int i=0;i<204;i++){
        fwrite(&pagina->childs[i],sizeof(long),1,input);
    }
    return;
}

long writePageInFileLastPosition(btPage *pagina,FILE *input){
	fseek(input,0,SEEK_END);
	fwrite(&pagina->isLeaf,sizeof(bool),1,input);
    fwrite(&pagina->numberOfKeys,sizeof(short),1,input);
    for(int i=0;i<204;i++){
        fwrite(&pagina->records[i].key,sizeof(int),1,input);
        fwrite(&pagina->records[i].recordRRN,sizeof(long),1,input);
    }
    for(int i=0;i<204;i++){
        fwrite(&pagina->childs[i],sizeof(long),1,input);
    }
    return ftell(input);
}
