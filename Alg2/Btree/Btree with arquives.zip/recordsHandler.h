#ifndef RECORDSHANDLER_H_
#define RECORDSHANDLER_H_

#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Btree.h"
#include "Node.h"


// Defines fixed size of record struct
#define RECORDSIZE 158

// Defines record info structure

long storeRecordOnFile(data*, FILE*);
data *getRecordFromFile(FILE* output,long rrn);
void printRecordInfo(data*);
void updateRecordOnFile(data *, FILE *,long);

void writePageInFile(btPage *pagina,FILE *input,long rrn);
long writePageInFileLastPosition(btPage *pagina,FILE *input);
//getPagefromfile
header *readHeader(FILE *input);
long createHeader(FILE *input);
void setHeader(FILE *input, header *newHeader);
btPage *getPageFromFile(btPage *auxiliar,FILE* input,long rrn);
#endif //RECORDSHANDLER_H_