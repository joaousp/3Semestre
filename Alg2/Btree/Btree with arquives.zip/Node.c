#include "Node.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//essa funcao inicia o no

btPage* page_init(bool isLeaf) {
	btPage *node = malloc(sizeof(btPage));
	node->isLeaf = isLeaf;
	node->numberOfKeys = 0;
	node->records = (record*)calloc(MAXKEYS,sizeof(record));
	node->childs = (long*)calloc(MAXKEYS,sizeof(long));
	//preecher com -1 nas informacoes;
	int contador=0;
	while(contador<MAXKEYS){
		node->records[contador].key=-1;
		node->records[contador].recordRRN=-1;
		node->childs[contador]=-1;
	}
	
	return node;
}
